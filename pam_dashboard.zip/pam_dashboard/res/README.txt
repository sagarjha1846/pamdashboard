DashBoard 3.0.0
-----------------

Releases:
3.0.0 : Added new look for UI Pages, by Sudesh on 28-Sep-2020
2.1.0 : Added new DB for OLD VLD Live Data, by Sudesh on 20-Sep-2020
2.0.1 : Minor fix for table header DB, by Sudesh on 19-Sep-2020
2.0.0 : Added New page for Statistics data for weight Differences, by Sudesh on 17-Sep-2020
1.0.3 : Fixed issue with Communication Settings not saved in DB, by Sudesh on 17-Jul-2020
1.0.2 : Added button in other settings page for stoping the modbus, in case of emergency, by Sudesh on 16-Jul-2020
1.0.1 : Changed calling of modbus_scan module from main file instead of lib
1.0.0 : Created new installer for Dashboard


Dashboard is web application created for plant process & Production monitoring. 
Various features are listed below

Supported OS: Windows 7, 10

pam_dashboard Copyright (C) 2020 xargs.

The main features of pam_dashboard : 

  - Monitors and display Cylinder production summary
  - Shaows Stistics Summary for weight differences.
  - Providsion to show tabular and graphical data for live and histroy data points.
  - Other machine tab show cases data for OLD and VLD machines.
  - Settings is password protected and has provsion to set communication, machine, and table header data.
  - Some more features on communication status along with summary data on Home page.


Dashboard is developed using Python, Javascript and PHP modules.


  This distribution contains the following files:

  pam_dashboard.exe      - For installing and launching dashboard app
  archivered pam_dashboard(Folder)  - Folder Containing all the required library and utilities
  README.txt    		- This file
 

---
End of document
