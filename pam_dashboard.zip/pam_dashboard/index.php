<?php

include('config.php');

$dirty = false;
foreach(headers_list() as $header) {
    if($dirty) continue; // I already know it needs to be cleaned
    if(preg_match('/Set-Cookie/',$header)) $dirty = true;
}
if($dirty) {
    $phpversion = explode('.',phpversion());
    if($phpversion[1] >= 3) {
        header_remove('Set-Cookie'); // php 5.3
    } else {
        header('Set-Cookie:'); // php 5.2
    }        
}

    $output = shell_exec("python test1.py");

    $findme = 'already';
    
    $pos = strpos($output, $findme);
    
    function execInBackground($cmd){
        if (substr(php_uname(), 0, 7) == "Windows"){ 
            pclose(popen("start /B ". $cmd, "r"));  
        }else{ 
        exec($cmd . " > /dev/null &");   
        } 
    } 
    
    if ($pos !== false) {
        #Process is already running... 
    }

    else {
        #Process not running... let's start it
        execInBackground('C:\xampp\php\php.exe runpython.php');
    }
     

?>

<html>

    <head>
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        
        <script src="js/navbar/jquery-3.5.1.min.js"></script>
  
        <link rel="stylesheet" href="css/jquery-ui.css" />
        
        <link rel="stylesheet" href="css/style.css" />
  
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js"></script>
    
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/echarts-gl/dist/echarts-gl.min.js"></script>
      
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/echarts/dist/extension/bmap.min.js"></script>
        
        <script type="text/javascript" src="js/navbar/jquery-ui.js"></script>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.3/FileSaver.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
        
        <script src="https://kit.fontawesome.com/3f06f3744c.js" crossorigin="anonymous"></script>
    
        
        <title>Plc Dashboard</title>
    
    </head>
    
    <body>
               
        <nav class="navbar">
            
            <div class="logos1">
                <img src="res/download.png" alt="" srcset="">
                <div class="humburger">
                    <div class="icon cancel-btn">
                        <i class="fas fa-times"></i>
                    </div>
                    
                    <div class="icon menu-btn">
                        <i class="fas fa-bars"></i>
                    </div>
                </div>
            </div>

            <div class="hamburgermenu">
                
                <div class="machineData">
                    <div class="machineheader">
                        <h3 id="projectheading">PLC Based Auto Filling System</h3>
                    </div>
                    <div class="machineDetail">
                        <label class="machineType">Machine Type:</label>
                        <select id="selectmachine">
                            
                            <?php
                            
                            $mainmachine = "SELECT * FROM tableheader WHERE status = 1";
                            
                            $statement = $connect->prepare($mainmachine);
                            $statement->execute();
                            $result = $statement->fetchAll();

                            foreach ($result as $row) {
                                echo '<option value="' . $row["ID"] . '">' . $row["machinename"] . '</option>';
                            }
                            ?>

                        </select>
                    </div>
                </div>

                <div class="softwearDetail">
                    <p class="DateTime">DateTime <span class="span" id="date"></span><span class="span" id="time"></span></p>
                    <p class="DateTime">Version:<span class="span" id="version"> </span></p>
                    <div class="connection"><p class="DateTime">Comm Status:</p><span id="circle"></span></div> 
                </div>

                <div class="logos2">
                    <img src="res/customerlogo.png" alt="" srcset="">
                </div>

            </div>

        </nav>

        <div class="container">
                    
            <div class="row row_space">

                <div class="col-sm-3">

                    <div class="productionRate">

                        <div id="productionRate_data_1"></div>

                        <div id="productionRate_data_2"></div>

                        <div id="productionRate_data_3"></div>

                        <div id="productionRate_data_4"></div>

                        <div id="productionRate_data_5"></div>

                        <div id="productionRate_data_6"></div>

                    </div>

                    <div class="filterSections">
                        <div class="title container">
                            <h3 class="text">FILTER :-</h3>
                            <button class="filter_graph btn_button">Apply</button>
                        </div>
                        <div class="filterOption">
                            <div class="LiveOrHistory">
                                <div class="livedata">
                                    <input class="filtersoption r1" type="radio" name="status" checked>
                                    <label>Live</label>
                                </div>
                                <div class="Historydata">
                                    <input class="filtersoption r2" type="radio" name="status">
                                    <label>History</label>
                                </div>
                                <div class="Lagdata">
                                    <input class="filtersoption r3" type="radio" name="status">
                                    <label>Lag Data</label>
                                </div>
                            </div>
                            <div class="Date_Time">
                                <div class="from">
                                    <label>From:</label>
                                    <input class="filtersoptions enableFrom" type="datetime-local" id="from_date" disabled="disabled"><br>
                                </div>
                                <div class="to">
                                    <label>To:</label>
                                    <input class="filtersoptions enableTo" type="datetime-local" id="to_date" disabled="disabled"><br>
                                </div>
                            </div>
                            <div class="customer">
                                <label>By Customer:</label>
                                <select name="customer_filter" id="customer_filters" class=" selectpicker">
                                    <option value="all">Default All</option>
                                    <?php

                                    $query = "SELECT * FROM customer";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {

                                        echo '<option value="' . $row["CUSTOMER"] . '">' . $row["CUSTOMER"] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="Machine">
                                <label>By Machine: </label>
                                <select name="machine_filter" id="machine_filters" class=" selectpicker ">
                                    <option value="all">Default All</option>

                                    <?php

                                    $query = "SELECT * FROM machine";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {
                                        echo '<option   value="' . $row["MACHINE"] . '">' . $row["MACHINE"] . '</option>';
                                    }

                                    ?>
                                </select>
                            </div>
                            <div class="Net">
                                <label class="ByNetWtId label1">By Net Wt.:</label>

                                <select name="net_filter" id="net_filters" class=" selectpicker ">

                                    <option value="all">Default All</option>

                                    <?php

                                    $query = "SELECT DISTINCT(net) FROM productiondetail WHERE status = 1 ORDER BY net ASC";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {
                                        echo '<option value="' . $row["net"] . '">' . $row["net"] . '</option>';
                                    }

                                    ?>


                                </select>
                            </div>
                            <div class="Res">
                                <label class="ByResWtId label1">By Res Wt.:</label>

                                <select name="res_filter" id="res_filters" class=" selectpicker ">

                                    <option value="all">Default All</option>

                                    <?php

                                    $query = "SELECT DISTINCT(residual) FROM productiondetail WHERE    status = 1 ORDER BY residual ASC";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {
                                        echo '<option   value="' . $row["residual"] . '">' . $row["residual"] . '</option>';
                                    }

                                    ?>


                                </select>
                            </div>
                            <div class="CylinderStatus">
                                <label class="ByCyTypeId label1">By Cy. Type:</label>

                                <select name="cyType_filter" id="cytype_filters" class=" selectpicker">

                                    <option value="all">Default All</option>

                                    <?php

                                    $query = "SELECT * FROM cylindertype";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {

                                        echo '<option value="' . $row["CYTYPE"] . '">' . $row["CYTYPE"] . '</option>';
                                    }

                                    ?>


                                </select>
                            </div>
                            <div class="CylinderType">
                                <label class="ByCyStatusId label1">By Cy. Status:</label>

                                <select name="cyStatus_filter" id="cystatus_filters" class=" selectpicker">

                                    <option value="all">Default All</option>

                                    <?php

                                    $query = "SELECT * FROM cylinderstatus";
                                    $statement = $connect->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();
                                    foreach ($result as $row) {

                                        echo '<option   value="' . $row["CYSTATUS"] . '">' . $row["CYSTATUS"] . '</option>';
                                    }

                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
               
                </div>

                <div class="col-lg-9">

                    <div class="tab tabhelp">

                        <button class="tablinks links" onclick="openTab(event, 'Home')">

                            <svg class="bi bi-house-fill" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5   0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>

                                <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>

                            </svg>

                            <span>Home</span>

                        </button>

                        <button class="tablinks links tablularData" onclick="openTab(event, 'Table')">

                            <svg class="bi bi-table" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>

                                <path fill-rule="evenodd" d="M15 4H1V3h14v1z"/>

                                <path fill-rule="evenodd" d="M5 15.5v-14h1v14H5zm5 0v-14h1v14h-1z"/>

                                <path fill-rule="evenodd" d="M15 8H1V7h14v1zm0 4H1v-1h14v1z"/>

                                <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2H0V2z"/>

                            </svg>

                            <span>Table</span>

                        </button>

                        <button class="tablinks links active graphic"  onclick="openTab(event, 'Graphs')">

                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-bar-chart-line" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M4 11H2v3h2v-3zm5-4H7v7h2V7zm5-5h-2v12h2V2zm-2-1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1h-2zM6 7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7zm-5 4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-3z"/>

                                <path fill-rule="evenodd" d="M0 14.5a.5.5 0 0 1 .5-.5h15a.5.5 0 0 1 0 1H.5a.5.5 0 0 1-.5-.5z"/>

                            </svg>

                            <span>Graph</span>

                        </button>

                        <button class="tablinks links"  onclick="openTab(event, 'Statistic')">

                            <svg class="bi bi-graph-up" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path d="M0 0h1v16H0V0zm1 15h15v1H1v-1z"/>

                                <path fill-rule="evenodd" d="M14.39 4.312L10.041 9.75 7 6.707l-3.646 3.647-.708-.708L7 5.293 9.959 8.25l3.65-4.563.781.624z"/>

                                <path fill-rule="evenodd" d="M10 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V4h-3.5a.5.5 0 0 1-.5-.5z"/>

                            </svg>

                            <span>Statistic</span>

                        </button>

                        <button class="tablinks links" onclick="openTab(event, 'otherMachine')">

                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-calculator" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm2 .5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-2zm0 4a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zM4.5 9a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zM4 12.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zM7.5 6a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zM7 9.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm.5 2.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zM10 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm.5 2.5a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 0-.5-.5h-1z"/>

                            </svg>

                            <span>Other Machine</span>

                            <input type="radio" style="display:none;" class="checked">

                        </button>

                        <button class="tablinks" onclick="openTab(event, 'Setting')">

                            <svg class="bi bi-gear-fill" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M9.405 1.05c-.413-1.4-2.397-1.4-2.81 0l-.1.34a1.464 1.464 0 0 1-2.105.872l-.31-.17c-1.283-.698-2.686.705-1.987 1.987l.169.311c.446.82.023 1.841-.872 2.105l-.34.1c-1.4.413-1.4 2.397 0 2.81l.34.1a1.464 1.464 0 0 1 .872 2.105l-.17.31c-.698 1.283.705 2.686 1.987 1.987l.311-.169a1.464 1.464 0 0 1 2.105.872l.1.34c.413 1.4 2.397 1.4 2.81 0l.1-.34a1.464 1.464 0 0 1 2.105-.872l.31.17c1.283.698 2.686-.705 1.987-1.987l-.169-.311a1.464 1.464 0 0 1 .872-2.105l.34-.1c1.4-.413 1.4-2.397 0-2.81l-.34-.1a1.464 1.464 0 0 1-.872-2.105l.17-.31c.698-1.283-.705-2.686-1.987-1.987l-.311.169a1.464 1.464 0 0 1-2.105-.872l-.1-.34zM8 10.93a2.929 2.929 0 1 0 0-5.86 2.929 2.929 0 0 0 0 5.858z"/>

                            </svg>

                            <span>Setting</span>

                        </button>

                        <button class="help" >

                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-question-octagon-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

                                <path fill-rule="evenodd" d="M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM6.57 6.033H5.25C5.22 4.147 6.68 3.5 8.006 3.5c1.397 0 2.673.73 2.673 2.24 0 1.08-.635 1.594-1.244 2.057-.737.559-1.01.768-1.01 1.486v.355H7.117l-.007-.463c-.038-.927.495-1.498 1.168-1.987.59-.444.965-.736.965-1.371 0-.825-.628-1.168-1.314-1.168-.901 0-1.358.603-1.358 1.384zm1.251 6.443c-.584 0-1.009-.394-1.009-.927 0-.552.425-.94 1.01-.94.609 0 1.028.388 1.028.94 0 .533-.42.927-1.029.927z"/>

                            </svg>

                            <span> <a href="doc\UserManual_dashboard.pdf" target="_blank">Help</a> -</span>


                        </button>

                    </div>

                    <div id="Home" class="tabcontent">

                        <div class="homeContent">
                            <div class="col-sm-3">
                                <div class="AFS" id="home_1"></div>
                                <div class="WCM" id="home_4"></div>
                                <div  id="home_7"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class="POM" id="home_2"></div>
                                <div class="SQC" id="home_5"></div>
                                <div id="home_8"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class="PM" id="home_3"></div>
                                <div class="DOSING" id="home_6"></div>
                            </div>
                        </div>

                        <div class="footer" style="background-color: #e3f2fd;">
                            <img src="res/browser.png" id="image" onclick="generate();">
                        </div>

                    </div>

                    <div id="Table" class="tabcontent">

                        <div class="container">
                            <div class="table_data"></div>
                            <div class="table_data_1"></div>
                            <div class="table_data_2"></div>
                            <div class="table_data_3"></div>
                            <div class="table_data_4"></div>
                            <div class="table_data_5"></div>
                            <div class="table_data_6"></div>
                        </div>

                        <div class="footer" style="background-color: #e3f2fd;">

                            <img src="res/browser.png" class="footerLogo"  id="image" onclick="generate();">

                            <img src="res/excel.png" class="footerLogo" id="myBtn">

                            <img src="res/column.png" class="footerLogo" id="clearTable">

                        </div>

                    </div>  

                    <div id="Graphs" class="tabcontent  active">

                        <div class="table-responsive">

                            <div id="container" style="height: 500px;"></div>

                            <div id="container_graph" style="height: 500px;"></div>

                        </div>

                        <div class="footer" style="background-color: #e3f2fd;">

                            <img src="res/browser.png" class="footerLogo"  id="image" onclick="generate();">

                            <img src="res/excel.png" class="footerLogo" id="myBtn">

                            <img src="res/column.png" class="footerLogo" id="clearTable">

                        </div>

                    </div>

                    <div id="Statistic" class="tabcontent">

                        <div class="container">

                            <div class="table-responsive">

                                <div class="graphSummary" id="graphSummary">


                                </div>

                                <div class="graphSummary_1" id="graphSummary">


                                </div>

                                <div class="graphSummary_2" id="graphSummary">


                                </div>

                            </div>

                        </div>

                        <div class="footer" style="background-color: #e3f2fd;">

                            <img src="res/browser.png" class="footerLogo"  id="image" onclick="generate();">

                            <img src="res/excel.png" class="footerLogo" id="myBtn">

                            <img src="res/column.png" class="footerLogo" id="clearTable">

                        </div>

                    </div>

                    <div id="otherMachine" class="tabcontent">

                        <div class="vld_old_row">

                            <div class="vlds vld">


                            </div>

                            <div class="olds old">


                            </div>     

                        </div>

                        <div class="vld_old_row">

                            <div class="vlds">
                                <div id="vld_pie_chart" style="width: 400px; height: 500px;"></div>
                            </div>

                            <div class="olds">
                                <div id="old_pie_chart" style="width: 400px; height: 500px;"></div>
                            </div>     

                        </div>

                        <div class="footer" style="background-color: #e3f2fd;">

                            <img src="res/browser.png" class="footerLogo"  id="image" onclick="generate();">

                            <img src="res/excel.png" class="footerLogo" id="myBtn">

                            <img src="res/column.png" class="footerLogo" id="clearTable">

                        </div>


                    </div>

                    <div id="Setting" class="tabcontent">

                        <div id="containers">

                            <div class="SetttingTabPassword">

                                <div id="errorMessage"></div>

                                <div class="settingSignup">

                                    <h4>ADMIN LOGIN</h4>

                                    <small>You would only be able to login using Admin Authority</small>

                                    <hr class="mb-4">

                                    <br>

                                    <label for="password" id="passwordlabel">Password</label>

                                    <input type="password" name="password" id="password">

                                    <br>
                                    
                                    <button id="submitButton" class="btn_button" value="Sign Up">Submit</button>

                                </div>

                            </div>

                            <div class="settingTabsPass" >

                                <div id="tabs">

                                <ul>
                                    <li><a href="#tabs-1">Machine Code</a></li>
                                    <li><a href="#tabs-2">Rejection Code</a></li>
                                    <li><a href="#tabs-3">Type of Cylinder</a></li>
                                    <li><a href="#tabs-4">Customer</a></li>
                                    <li><a href="#tabs-5">Table Header</a></li>
                                    <li><a href="#tabs-6">Communication</a></li>
                                    <li><a href="#tabs-7">Add Machine</a></li>
                                    <li><a href="#tabs-8">Add Customer</a></li>
                                    <li><a href="#tabs-9">Other Setting</a></li>
                                </ul>

                                    <div id="tabs-1">

                                        <div class="container">

                                            <div class="table-responsive">  

                                                <div id="live_data"></div>                 

                                            </div> 

                                        </div>

                                    </div>

                                    <div id="tabs-2">

                                        <div class="container">

                                            <div class="table-responsive">  

                                                <div id="rejectioncode"></div>                 

                                            </div> 

                                        </div>

                                    </div>

                                    <div id="tabs-3">

                                        <div class="container">

                                            <div class="table-responsive">  

                                                <div id="cylindertype"></div>                 

                                            </div> 

                                        </div>

                                    </div>

                                    <div id="tabs-4">

                                        <div class="container">

                                            <div class="table-responsive">  

                                                <div id="customertable"></div>     

                                            </div> 

                                        </div>

                                    </div>

                                    <div id="tabs-5">

                                        <div class="admin">

                                            <div class="AdminLogin">

                                                <h4>ADMIN LOGIN</h4>

                                                <small>You would only be able to login using Admin Authority</small>

                                                <hr class="mb-4">

                                                <label>Password:</label>

                                                <input type="password" id="Password" /><br>

                                                <button class="btn_button" id="adminlogin" style="margin:20px auto">Submit</button>

                                            </div> 

                                        </div>

                                        <div class="container">

                                            <div id="tableheader"></div>                 

                                        </div>

                                    </div>

                                    <div id="tabs-6">

                                        <div class="container">
                                            
                                            <div class="dropdowns">
                                                
                                                <div>
                                                    <label class="Communication">Communication</label>

                                                    <select id="Comm">

                                                        <?php


                                                        $mainmachine = "SELECT * FROM `set_comm`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["COMMUNICATION"].'">'.$row["COMMUNICATION"].'</option>';

                                                        }

                                                        ?>

                                                        <?php


                                                            $mainmachine = "SELECT * FROM `communication`";

                                                            $statement = $connect->prepare($mainmachine);
                                                            $statement->execute();
                                                            $result = $statement->fetchAll();

                                                            foreach($result as $row)
                                                            {
                                                            echo '<option value="'.$row["COMMUNICATION"].'">'.$row["COMMUNICATION"].'</option>';

                                                        }

                                                        ?>

                                                     </select>
                                                </div>

                                                <div>
                                                    <label class="Communication">Baudrate</label>

                                                    <select id="Baudrate">



                                                       <?php


                                                            $mainmachine = "SELECT * FROM `set_comm`";

                                                            $statement = $connect->prepare($mainmachine);
                                                            $statement->execute();
                                                            $result = $statement->fetchAll();

                                                            foreach($result as $row)
                                                            {
                                                            echo '<option value="'.$row["BAUDRATE"].'">'.$row["BAUDRATE"].'</option>';

                                                        }

                                                        ?>


                                                       <?php


                                                            $mainmachine = "SELECT * FROM `communication`";

                                                            $statement = $connect->prepare($mainmachine);
                                                            $statement->execute();
                                                            $result = $statement->fetchAll();

                                                            foreach($result as $row)
                                                            {
                                                            echo '<option value="'.$row["BAUDRATE"].'">'.$row["BAUDRATE"].'</option>';

                                                        }

                                                        ?>

                                                    </select>
                                                </div>

                                                <div>
                                                    <label class="Communication" >Parity</label>

                                                <select id="Parity">



                                                   <?php


                                                        $mainmachine = "SELECT * FROM `set_comm`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["PARITY"].'">'.$row["PARITY"].'</option>';

                                                    }

                                                    ?>


                                                    <?php


                                                        $mainmachine = "SELECT * FROM `communication`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["PARITY"].'">'.$row["PARITY"].'</option>';

                                                    }

                                                    ?>

                                                 </select>
                                                </div>

                                                <div>
                                                    <label class="Communication" >Databit</label>

                                                <select id="Databit">

                                                   <?php


                                                        $mainmachine = "SELECT * FROM `set_comm`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["DATABIT"].'">'.$row["DATABIT"].'</option>';

                                                    }

                                                    ?>

                                                  <?php


                                                        $mainmachine = "SELECT * FROM `communication`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["DATABIT"].'">'.$row["DATABIT"].'</option>';

                                                    }

                                                    ?>

                                                </select>
                                                </div>

                                                <div>
                                                    <label class="Communication" >Stopbit</label>

                                                <select id="Stopbit">

                                                   <?php


                                                        $mainmachine = "SELECT * FROM `set_comm`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                        echo '<option value="'.$row["STOPBIT"].'">'.$row["STOPBIT"].'</option>';

                                                    }

                                                    ?>

                                                     <?php


                                                        $mainmachine = "SELECT * FROM `communication`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {


                                                            echo '<option value="'.$row["STOPBIT"].'">'.$row["STOPBIT"].'</option>';

                                                        }

                                                        ?>

                                                </select>
                                                </div>

                                            </div>
                                            
                                            <div class="footer">

                                                    <button class="btn_button" id="set_commu">SET</button>
                                                
                                                    <button class="btn_button">RESET</button>

                                            </div>
                                            
                                        </div>

                                    </div>

                                    <div id="tabs-7">

                                        <div class="addMachine">

                                            <div class="container">

                                                <div class="machinetable">

                                                    <div class="machinecol" id="addMachine">

                                                    </div>

                                                    <div class="">

                                                        <div class="dropdowns">

                                                            <h4>Add New Machine</h4>

                                                            <div>

                                                                <label>Machine Id</label>

                                                                <input required class="form-control machine_code" type="text"/>

                                                            </div>

                                                            <div>

                                                                <label>Machine Type</label>

                                                                <select class="form-control machine_type">

                                                                    <option value="Auto Filling System">Auto Filling System</option>

                                                                    <option value="Oring Leaking Detector">Oring Leaking    Detector</option>

                                                                    <option value="Valve Leaking Detector">Valve Leaking Detector</option>

                                                                    <option value="SQC">SQC</option>

                                                                    <option value="Purging  Machine">Purging  Machine</option>

                                                                    <option value="Weight Correction Unit">Weight Correction Unit</option>

                                                                    <option value="Pincut and Oring Missing Machine">Pincut and Oring Missing Machine</option>

                                                                    <option value="Dosing System">Dosing System</option>


                                                                </select>

                                                            </div>

                                                            <div >

                                                                <label>Machine Status</label>

                                                                <select class="form-control status" required >

                                                                    <option     value="1">Enable</option>

                                                                    <option value="0">Disable</option>

                                                                </select>

                                                            </div>

                                                            <button id="submit_machine_detail" class="btn_button">Add New Machine</button>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div id="tabs-8">

                                        <div class="container">

                                            <div class="machinetable">

                                                <div class="col-sm-6" id="addCustomer">

                                                </div>

                                                <div class="col-sm-6">

                                                    <div class="dropdowns">

                                                        <h4>Customer Detail</h4>
                                                        
                                                        <div>

                                                            <label for="name">Customer Name</label>

                                                            <input type="text" class="form-control" name="name" placeholder="Enter name" id="nameS" required />

                                                        </div>

                                                        <div>

                                                            <label for="file">File</label>

                                                            <input type="file"  class="form-control" id="logoS" name="file" required accept=".jpg, .png"/>

                                                        </div>

                                                        <div>

                                                            <label>Machine Status</label>

                                                            <select id="StatusS" class="form-control" required >

                                                                <option value="Enable">Enable</option>

                                                                <option value="Disable">Disable</option>

                                                            </select>

                                                        </div>

                                                        <button class="btn_button" id="submitBtn">Submit</button>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div id="tabs-9">
                                        
                                        <div class="container">
                                        

                                            <h4>Histogram Limits</h4>

                                            <div class="row_border" >

                                                <div class="col-md-3">

                                                    <label style="margin-right:20px;">Least Count:</label>

                                                    <?php


                                                    $mainmachine = "SELECT * FROM `othersettings`";

                                                    $statement = $connect->prepare($mainmachine);
                                                    $statement->execute();
                                                    $result = $statement->fetchAll();

                                                    foreach($result as $row)
                                                    {


                                                        echo'<input type="text" id="leastCount"  value='.$row["leastcount"].'>';

                                                    }

                                                    ?>

                                                </div>

                                                <div class="col-md-3">

                                                    <label style="margin-right:20px;">Range From:</label>

                                                    <?php


                                                    $mainmachine = "SELECT * FROM `othersettings`";
                                                    $statement = $connect->prepare($mainmachine);
                                                    $statement->execute();
                                                    $result = $statement->fetchAll();

                                                    foreach($result as $row)
                                                    {

                                                        echo'<input type="text" id="rangeFrom"  value='.$row["rangefrom"].'>';

                                                    }

                                                    ?>

                                                </div>

                                                <div class="col-md-3">

                                                    <label style="margin-right:34px;">Range To:</label>


                                                   <?php


                                                        $mainmachine = "SELECT * FROM `othersettings`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {


                                                            echo'<input type="text" id="rangeTo"  value='.$row["rangeto"].'>';

                                                        }

                                                    ?>

                                                </div>

                                                <div class="col-md-3">

                                                    <button  class="btn_button" id="setHistogramLimits">Set</button>

                                                </div>

                                            </div>

                                            <h4>Daily Backup Plan For Everyday</h4>

                                            <div class="row_border_1">

                                                <div class="col-md-3">

                                                    <button class="btn btn-primary btn-lg" id="backup">Set File Location</button>

                                                </div>

                                                <div class="col-md-3">

                                                    <input style="margin-top:10px;" type="url" id="filelocation"/>

                                                </div>

                                                <div class="col-md-3" >

                                                    <label>Backup F/p Time:</label>


                                                    <?php


                                                        $mainmachine = "SELECT * FROM `othersettings`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                            echo'<input style="margin-top:10px;" type="time" id="backuptime"  value='.$row["backuptime"].'>';

                                                        }
                                                    ?>

                                                </div>

                                                <div class="col-md-3">

                                                    <button style="margin-top:10px;" class="btn_button" id="setBackupTime">Set</button>

                                                </div>

                                            </div>

                                            <h4>No Of Records Displayed in Histogram</h4>

                                            <div class="row_border_2">

                                                <div class="col-md-5" >

                                                        <label>Enter the last no of records displayed in Histogram:</label>

                                                    </div>

                                                <div class="col-md-4" >



                                                     <?php


                                                        $mainmachine = "SELECT * FROM `othersettings`";

                                                        $statement = $connect->prepare($mainmachine);
                                                        $statement->execute();
                                                        $result = $statement->fetchAll();

                                                        foreach($result as $row)
                                                        {

                                                            echo '<input style="margin-top:10px;" type="text" id="histogramlimit"  value='.$row["histogramlimit"].'>';

                                                        }
                                                    ?>

                                                </div>

                                                <div class="col-md-3">

                                                    <button style="margin-top:10px;" class="btn_button" id="setNoOfRecords">Set</button>

                                                </div>

                                            </div>

                                            <div class="row_border_3">

                                                <div class="col-md-3" >

                                                    <h4>Launch Installer :- </h4>

                                                </div>

                                                <div class="col-md-3">

                                                    <input type="button" value="Launch Installer" class="btn_button" id="launch"/>

                                                </div>

                                            </div>


                                        </div>
                                        
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>
       
        <footer>

            <div id="copyRight">

                <div class="row">

                    <p><b>&#169; 2020 Xargs Pvt. Ltd. All Rights Reserved.</b></p>

                </div>

            </div>

        </footer>

        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
   
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

        <script src="js/navbar/navbar.js"></script>
        
        <script src="js/navbar/comm_led.js"></script>

        <script src="js/navbar/machine_name.js"></script>

        <script src="js/tab/home_tab.js"></script>
        
        <script src="js/tab/other_machine_tab.js"></script>
        
        <script src="js/tab/production_summary.js"></script>
        
        <script src="js/filters/fetch_graph.js"></script>
        
        <script src="js/filters/filter_graph_data.js"></script>

        <script src="js/filters/filter_table.js"></script>

        <script src="js/filters/fetch_table.js"></script>
        
        <script src="js/setting_tab/Add_machine.js"></script>
        
        <script src="js/setting_tab/communication.js"></script>
        
        <script src="js/setting_tab/launch.js"></script>
        
        <script src="js/setting_tab/Adminpanel.js"></script>
        
        <script src="js/setting_tab/setting_tab.js"></script>

        <script src="js/setting_tab/sigin_up.js"></script>
        
        <script src="js/exportfiles/clear_btn.js"></script>
        
        <script src="js/exportfiles/screenshot.js"></script>
        
        <script src="js/exportfiles/excelSummary.js"></script>
        
        <script src="js/exportfiles/exportToexcel.js"></script>

        <script src="js/exportfiles/tableSummary.js"></script>
        
        <script src="js/exportfiles/graph_table.js"></script>
        
    </body>
    
</html>