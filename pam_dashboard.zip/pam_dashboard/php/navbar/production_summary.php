
<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$query = "
    SELECT * FROM productionrate LIMIT 1 
    ";

$output = '';

if(isset($_POST['machine']) && $_POST['machine'] != '' )
{
    
    $machineid = $_POST['machine'];
    
    if($machineid == '1'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="CylinderCheckedHeader">Cylinder Checked &emsp;&emsp;&nbsp;&nbsp;:&emsp;<span id="CylinderChecked"> '.$row["CylinderChecked"].' Nos</span></h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                <h5 class="UnderFilledCylinderHeader">Under Filled Cylinder &emsp;:&emsp;<span id="UnderFilledCylinder"> '.$row["UnderFilledCylinder"].' Nos</span></h5>

                <h5 class="OverFilledCylinderHeader ">Over Filled Cylinder &emsp;&emsp;:&emsp;<span id="OverFilledCylinder"> '.$row["OverFilledCylinder"].' Nos </span> </h5>
                        ';
            }

        }

    }
    
    if($machineid == '2'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Rejected Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                ';
            }

        }

    }
    
    if($machineid == '3'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Rejected Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                ';
            }

        }

    }
    
    if($machineid == '4'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="CylinderCheckedHeader">Cylinder Checked &emsp;&emsp;&nbsp;&nbsp;:&emsp;<span id="CylinderChecked"> '.$row["CylinderChecked"].' Nos</span></h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                <h5 class="UnderFilledCylinderHeader">Under Filled Cylinder &emsp;:&emsp;<span id="UnderFilledCylinder"> '.$row["UnderFilledCylinder"].' Nos</span></h5>

                <h5 class="OverFilledCylinderHeader ">Over Filled Cylinder &emsp;&emsp;:&emsp;<span id="OverFilledCylinder"> '.$row["OverFilledCylinder"].' Nos </span> </h5>
                        ';
            }

        }

    }
    
    if($machineid == '5'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="CylinderCheckedHeader">Cylinder Checked &emsp;&emsp;&nbsp;&nbsp;:&emsp;<span id="CylinderChecked"> '.$row["CylinderChecked"].' Nos</span></h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                <h5 class="UnderFilledCylinderHeader">Under Filled Cylinder &emsp;:&emsp;<span id="UnderFilledCylinder"> '.$row["UnderFilledCylinder"].' Nos</span></h5>

                <h5 class="OverFilledCylinderHeader ">Over Filled Cylinder &emsp;&emsp;:&emsp;<span id="OverFilledCylinder"> '.$row["OverFilledCylinder"].' Nos </span> </h5>
                        ';
            }

        }

    }

    if($machineid == '6'){
       
         $query = "
         SELECT * FROM productionrate WHERE ID = $machineid
         ";  

        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <h3 id="productionSummary">PRODUCTION SUMMARY</h3>

                <h5 class="ProductionRateHeader alert alert-dark" role="alert">Production Rate &emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:&emsp;  <span id="ProductionRate"> '.$row["ProductionRate"].' </span> Cyl/hr</h5>

                <h5 class="CylinderCheckedHeader">Cylinder Checked &emsp;&emsp;&nbsp;&nbsp;:&emsp;<span id="CylinderChecked"> '.$row["CylinderChecked"].' Nos</span></h5>

                <h5 class="AcceptedCylinderHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinder">'.$row["AcceptedCylinder"].' Nos</span></h5>

                <h5 class="AcceptedCylinderPercHeader">Accepted Cylinder &emsp;&emsp;&nbsp;:&emsp;<span id="AcceptedCylinderPerc">  '.$row["AcceptedCylinderPerc"].'%</span></h5>

                <h5 class="UnderFilledCylinderHeader">Under Filled Cylinder &emsp;:&emsp;<span id="UnderFilledCylinder"> '.$row["UnderFilledCylinder"].' Nos</span></h5>

                <h5 class="OverFilledCylinderHeader ">Over Filled Cylinder &emsp;&emsp;:&emsp;<span id="OverFilledCylinder"> '.$row["OverFilledCylinder"].' Nos </span> </h5>
                        ';
            }

        }

    }

}
    
echo $output;

?>