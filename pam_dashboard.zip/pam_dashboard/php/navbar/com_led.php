<?php
	
$con=mysqli_connect("localhost","root","","plcproject");

$sql = "SELECT STATUSBIT FROM set_comm";


$result = mysqli_query($con,$sql);


$rows = array();

while($r = mysqli_fetch_array($result)) {

    $rows[] = $r;

}

echo json_encode($rows);

mysqli_close($con);

?>
