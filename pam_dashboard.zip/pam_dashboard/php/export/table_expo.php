<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';

if(isset($_POST['act']))
{
   
    if($_POST['act'] == '0'){
        
        $act = $_POST['act']; 
        $limit = $_POST['limit'];
        $machinename = $_POST['machinename'];
      
        $command = escapeshellcmd("C:/xampp/htdocs/pam_dashboard/lib/graph_tables.pyc");

        //$data = shell_exec($command);
        
        
    }
    
    if($_POST['act'] == '1'){
        
        $customer = $_POST['customer']; 
        $machine = $_POST['machine'];
        $cytype = $_POST['cytype'];
        $cystatus = $_POST['cystatus'];          
        $net = $_POST['net'];         
        $res = $_POST['res'];          
        $from_date = '*';
        $to_date = '*';
        
        if (strpos($net, 'All') !== false) {
            $net = 'all';
        }
        if (strpos($res, 'All') !== false) {
            $res = 'all';
        }        
      
        
        $new_sql = '"'.$customer.'"' ." ".'"'.$machine.'"'." ".'"'.$cytype.'"'." ".'"'.$cystatus.'"'." ".'"'.$net.'"'." ".'"'.$res.'"'." ".'"'.$from_date.'"'." ".'"'.$to_date.'"';
        #print($new_sql);
        $command = escapeshellcmd("C:/xampp/htdocs/pam_dashboard/lib/graph_tables.pyc .$new_sql");
       
        $data = shell_exec($command);


    }
    
    if($_POST['act'] == '2'){
        
        $from_date = $_POST['from_date'];
        $to_date = $_POST['to_date'];
        $customer = $_POST['customer']; 
        $machine = $_POST['machine'];
        $cytype = $_POST['cytype'];
        $cystatus = $_POST['cystatus'];          
        $net = $_POST['net'];         
        $res = $_POST['res'];
        
        if (strpos($net, 'All') !== false) {
            $net = 'all';
        }
        if (strpos($res, 'All') !== false) {
            $res = 'all';
        }
        //############
                
        //############

        #$command = escapeshellcmd('C:/xampp/htdocs/plc_table_test/statistics.py .$from_date .$to_date .$customer .$res .$net .$cystatus .$cytype .$machine');
        $new_sql = '"'.$customer.'"' ." ".'"'.$machine.'"'." ".'"'.$cytype.'"'." ".'"'.$cystatus.'"'." ".'"'.$net.'"'." ".'"'.$res.'"'." ".'"'.$from_date.'"'." ".'"'.$to_date.'"';
        #print($new_sql);
        $command = escapeshellcmd("C:/xampp/htdocs/pam_dashboard/lib/graph_tables.pyc .$new_sql");
       
        $data = shell_exec($command);
        
    }
  
}

$query = "
SELECT * FROM `statistics` WHERE id!= 1
";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$total_row = $statement->rowCount();

    
$sql = "";


$sql = "
SELECT * FROM `statistics` WHERE id = 1;
";

$statement = $connect->prepare($sql);

$statement->execute();

$results = $statement->fetchAll();

$total_rows = $statement->rowCount();

    

$output .= '  
<table class="table table-responsive table-bordered table-hover scroll" id="graph_summary">  
<thead class="thead-dark">
';  
    

if($total_rows > 0)
{

    foreach($results as $row)

    {
        $output .= '
        <tr>
        <th width ="20">'.$row["a"].'</th>
        <th width="10%">'.$row["b"].'</th>
        <th width="10%">'.$row["c"].'</th>
        <th width="10%">'.$row["d"].'</th>
        <th width="10%">'.$row["e"].'</th>
        <th width="10%">'.$row["f"].'</th>
        <th width="10%">'.$row["g"].'</th>
        <th width="10%">'.$row["h"].'</th>
        <th width="10%">'.$row["i"].'</th>
        <th width="10%">'.$row["j"].'</th>
        <th width="10%">'.$row["k"].'</th>
        <th width="10%">'.$row["l"].'</th>
        <th width="10%">'.$row["m"].'</th>

        </tr>
        ';
    }

}



$output .= '
</thead>
<tbody>
'; 


if($total_row > 0)
{

    foreach($result as $row)

    {
        $output .= '
        <tr>
        <td>'.$row["a"].'</td>
        <td>'.$row["b"].'</td>
        <td>'.$row["c"].'</td>
        <td>'.$row["d"].'</td>
        <td>'.$row["e"].'</td>
        <td>'.$row["f"].'</td>
        <td>'.$row["g"].'</td>
        <td>'.$row["h"].'</td>
        <td>'.$row["i"].'</td>
        <td>'.$row["j"].'</td>
        <td>'.$row["k"].'</td>
        <td>'.$row["l"].'</td>
        <td>'.$row["m"].'</td>
        </tr>
        ';

    }

}

$output .= '

</tbody>   
<table>

';




echo $output;





?>
