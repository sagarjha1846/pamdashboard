<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plcproject";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


    
if(isset($_POST['clear']) && $_POST['clear'] == '1' )
{
// sql to delete a record
$sql = "DELETE FROM productiondetail_live WHERE status = 1";
    
    if ($conn->query($sql) === TRUE) {
      echo "Record deleted successfully";
    } else {
      echo "Error deleting record: " . $conn->error;
    }
    
$sql = "UPDATE productionrate SET ProductionRate = '0', CylinderChecked = '0', AcceptedCylinder = '0', AcceptedCylinderPerc = '0', UnderFilledCylinder = '0', OverFilledCylinder = '0'";
    
    if ($conn->query($sql) === TRUE) {
      echo "Record deleted successfully";
    } else {
      echo "Error deleting record: " . $conn->error;
    }
    
$sql = "UPDATE vld_and_old SET OkCylinder = '0', RejCylinder = '0', ProductionRate = '0'";
    
    if ($conn->query($sql) === TRUE) {
      echo "Record deleted successfully";
    } else {
      echo "Error deleting record: " . $conn->error;
    }
    
}

$sql = "DELETE FROM vld_and_old_live WHERE status = 1";
    
    if ($conn->query($sql) === TRUE) {
      echo "Record deleted successfully";
    } else {
      echo "Error deleting record: " . $conn->error;
    }



$conn->close();
?>