<?php

$conn=mysqli_connect("localhost","root","","plcproject");

if(isset($_POST['limit']) && $_POST['limit'] != '' )
{
  
    $id = $_POST['limit'];
    
    $sql = "
    SELECT net, differences FROM productiondetail_live WHERE status = 1 ORDER BY Date DESC LIMIT $id 
    ";


    $sth = mysqli_query($conn,$sql);

    $rows = array();

    while($r = mysqli_fetch_assoc($sth)) {
 
        $rows[] = $r;

    }

    print json_encode($rows);
        
   
}
    


?>