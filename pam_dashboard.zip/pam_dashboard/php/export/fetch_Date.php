<?php

$con=mysqli_connect("localhost","root","","plcproject");
      // Check connection
if (mysqli_connect_errno())

{

    echo "Failed to connect to MySQL: " . mysqli_connect_error();

}

$sql = "
    SELECT differences, net FROM productiondetail WHERE status = 1
    ";

    if(isset($_POST["from_date"], $_POST["to_date"]))  
    {  
      $output = '';  
      $sql = "  
           AND Date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
      "; 
        
    }
     
   

    if(isset( $_POST['customer'])){

        if($_POST['customer'] != 'all'){

            $sql .= '
            AND customer = "'.$_POST['customer'].'" 
                ';
            
        }

        if($_POST['customer'] == 'all'){

            $sql .= '';

        } 

    }

        if(isset( $_POST['machine'])){

            if($_POST['machine'] != 'all'){

                $sql .= '
                AND machine = "'.$_POST['machine'].'" 
                ';

            }

            if($_POST['machine'] == 'all'){

                $sql .= '

                ';

            }


        }

        if(isset( $_POST['cytype'])){

            if($_POST['cytype'] != 'all'){

                $sql .= '
                AND cylindertype = "'.$_POST['cytype'].'" 
                ';

            }

            if($_POST['cytype'] == 'all'){

                $sql .= '
                        ';

            }


        }

        if(isset( $_POST['cystatus'])){

            if($_POST['cystatus'] != 'all'){

                $sql .= '
                AND cylinderstatus = "'.$_POST['cystatus'].'" 
                ';

            }

            if($_POST['cystatus'] == 'all'){

                $sql .= '';

            }


        }

        if(isset( $_POST['res'])){

            if($_POST['res'] != 'all'){

                $sql .= '
                AND residual = "'.$_POST['res'].'" 
                ';

            }

            if($_POST['res'] == 'all'){

                $sql .= '

                         ';

            }


        }

        if(isset( $_POST['net'])) {

            if($_POST['net'] != 'all'){

                $sql .= '
                AND net = "'.$_POST['net'].'" 
                ';

            }

            if($_POST['net'] == 'all'){

                $sql .= '';

            }
            
        }
        
        $sql .= '
                ORDER BY DATE DESC 
                ';
        
        
   
$result = mysqli_query($con,$sql);

$rows = array();
    
while($r = mysqli_fetch_array($result)) {
    
    $rows[] = $r['net'];
   
}
  echo json_encode($rows);

   
$results = mysqli_query($con,$sql);

$row = array();
    
while($r = mysqli_fetch_array($results)) {
    
    $row[] = $r['differences'];
   
}
  echo json_encode($row);



  mysqli_close($con);



?>
