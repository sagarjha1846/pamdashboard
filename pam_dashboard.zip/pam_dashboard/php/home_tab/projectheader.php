<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$query = "
SELECT * FROM tableheader LIMIT 1
";

if(isset($_POST['machine']) && $_POST['machine'] != '' )
{
    
   $id = $_POST['machine'];
    
    $query = "
    SELECT * FROM tableheader WHERE ID = $id
    ";
 
}


 
$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$total_row = $statement->rowCount();

$output = '';


        if($total_row > 0)
        {

            foreach($result as $row)

            {
                $output .= '
                
                <h2 id="projectheading">'.$row["projectheading"].'</h2>
                ';
            }

        }

        

       
echo $output;


?>