
<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$query = "
    SELECT * FROM productionrate LIMIT 1, 1
    ";

 
$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$total_row = $statement->rowCount();


$output = '';

$output .= '
        
           
                <div class="Header">
                            
                    <h4>PIN-CUT & ORING MISSING</h4>
                         
                </div>
                            
                <div class="Details">
                            
                    <img src="res/tool.png" class="cylinder">';
                                 

        if($total_row > 0)
        {
            
          

            foreach($result as $row)

            {
                $output .= '
                               
                        <h1>'.$row["ProductionRate"].'</h1> 
                        
                        ';
                
                      
            }

        }
$output .= '
    
            <p><b>Production Rate</b></p>

            <p><b>(Cylinder/Hours)</b></p>

        </div>

        <div class="Details">
                            
            <img src="res/tool%20(1).png" class="cylinder">
';

if($total_row > 0)
        {

            foreach($result as $row)

            {
                $output .= '
                               
                        <h1>'.$row["AcceptedCylinderPerc"].'</h1> 
                        
                        ';
                      
            }

        }

$output .= '
                <p><b>% accepted Cylinder</b></p>

            </div>

        ';
                                

        

       
echo $output;






?>