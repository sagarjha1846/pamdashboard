<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';  
    
$sql = "SELECT * FROM vld_and_old WHERE id = 1";

$statement = $connect->prepare($sql);
$statement->execute();
$results = $statement->fetchAll();
$row = $statement->rowCount();



if($row > 0)
{

    foreach($results as $row)

    {
           $output .= '
           
           
                                    <div>
            
                                        <h2>VLD</h2>

                                    </div>
                                    
                                    <div class="old_css">

                                        <div class="old_input">

                                            <label>Ok Cylinder :</label>

                                            <input type="text" id="OkCylinder_vld" value="'.$row["OkCylinder"].'"><br>

                                        </div>

                                        <div class="old_input">

                                            <label>Rej Cylinder :</label>

                                            <input type="text" id="RejCylinder_vld" value="'.$row["RejCylinder"].'"><br>

                                        </div>

                                        <div class="old_input">

                                            <label>Production Rate :</label>

                                            <input type="text" id="prorate_vld" value="'.$row["ProductionRate"].'"><br>

                                        </div>
                                

                                
           
           ';
        
    }
    
   
}
    

echo $output;  


?>