<?php

  $con=mysqli_connect("localhost","root","","plcproject");

  // Check connection
  if (mysqli_connect_errno())
  {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$sql = "
    SELECT * FROM vld_and_old WHERE id = 1  
    ";




  $result = mysqli_query($con,$sql);

  $rows = array();
  while($r = mysqli_fetch_array($result)) {
    $rows[] = $r;
  }
  echo json_encode($rows);

  mysqli_close($con);
?>