<?php

  $con=mysqli_connect("localhost","root","","plcproject");

  // Check connection
  if (mysqli_connect_errno())
  {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


	/*$sql = "
	//	SELECT differences FROM productiondetail WHERE status = 1 and Date > (CURRENT_DATE() - INTERVAL 1 DAY)   Date_Time >= //CAST(GETDATE() AS DATE)
    ";*/

$sql = "SELECT differences FROM productiondetail WHERE status = 1";

if(isset($_POST["from_date"], $_POST["to_date"]))  
 {  
    
      $sql .= "  
      AND Date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
      ";  
 
}

if(isset( $_POST['customer']))
{
 
    if($_POST['customer'] != 'all'){
      
        $sql .= '
       AND customer = "'.$_POST['customer'].'" 
     ';
        
    }
    
    if($_POST['customer'] == 'all'){
      
        $sql .= '
       
     ';
        
    } 
}



if(isset( $_POST['machine']))
{
    if($_POST['machine'] != 'all'){
      
        $sql .= '
       AND machine = "'.$_POST['machine'].'" 
     ';
        
    }
    
    if($_POST['machine'] == 'all'){
      
        $sql .= '
       
     ';
        
    }
     
      
}


if(isset( $_POST['cytype']))
{
    if($_POST['cytype'] != 'all'){
      
        $sql .= '
       AND cylindertype = "'.$_POST['cytype'].'" 
     ';
        
    }
    
    if($_POST['cytype'] == 'all'){
      
        $sql .= '
      
     ';
        
    }
     
      
}


if(isset( $_POST['cystatus']))
{
    if($_POST['cystatus'] != 'all'){
      
        $sql .= '
       AND cylinderstatus = "'.$_POST['cystatus'].'" 
     ';
        
    }
    
    if($_POST['cystatus'] == 'all'){
      
        $sql .= '
       
     ';
        
    }
     
      
}


if(isset( $_POST['net']))
{
    if($_POST['net'] != 'all'){
      
        $sql .= '
       AND net = "'.$_POST['net'].'" 
     ';
        
    }
    
    if($_POST['net'] == 'all'){
      
        $sql .= '
       
     ';
        
    }
     
      
}


if(isset( $_POST['res']))
{
    if($_POST['res'] != 'all'){
      
        $sql .= '
       AND residual = "'.$_POST['res'].'" 
     ';
        
    }
    
    if($_POST['res'] == 'all'){
      
        $sql .= '
       
     ';
        
    }
     
      
}



$result = mysqli_query($con,$sql);

$rows = array();
while($r = mysqli_fetch_array($result)) {
    $rows[] = $r['differences'];
}
  
  
  function get_values_Keys($lc, $frm, $to, $keys, $diff) {

		$band_limit  = $lc / 2;
		$col_limit = array();
		$total_col = count($keys);
		
		$first_key = '<'.strval($frm);
		$last_key = '>'.strval($to);
		$key_vals = array();
		$key_vals[$first_key] = 0;
		$key_vals[$last_key] = 0;
		$lastKey_count = 0;
		
		foreach($keys as $key) {
			$col_limit[$key] = array(($key - $band_limit), ($key + $band_limit));
			$key_vals[strval($key)] = 0;
		}
	 
		$cnt = 0;
		foreach($diff as $dif_val) {
			$val = $dif_val*1000;
			if ($val < $frm) {
				$key_vals[$first_key] += 1;
			}
			elseif ($val > $to){
				$lastKey_count += 1;
			}
			else {
				foreach($keys as $key) {
					if (($val >= $col_limit[$key][0]) and ($val < $col_limit[$key][1])){
						$key_vals[strval($key)] += 1;
						break;
					}
				}
			}
			$cnt += 1;
		}
		$key_vals[$last_key] = $lastKey_count;
		$out_row = array();
		$cnt = 0;
		$out_row[$cnt] = array( $first_key, $key_vals[$first_key]);
		$cnt = 1;		
		foreach($keys as $key) {
				$out_row[$cnt] = array(strval($key), $key_vals[$key]);
				$cnt += 1;
		}
		$out_row[$cnt] = array( $last_key, $key_vals[$last_key]);
		return $out_row;
	}

  
  $sql = "
    SELECT rangefrom, rangeto, leastcount FROM othersettings WHERE id = 1  
    ";

	$result_graphset = mysqli_query($con,$sql);

	$least_cnt = 0;
	$from_val = 0;
	$to_val = 0;
	
	while($r = mysqli_fetch_array($result_graphset)) {
		$from_val = $r["rangefrom"];
		$to_val = $r["rangeto"];
		$least_cnt = $r["leastcount"];
		}

	$keys = array();
	$key_vals_array = array(); 
	
	$cnt = 0;
	
	for ($x = $from_val; $x <= $to_val; $x+=$least_cnt) {
		$keys[$cnt] = $x;
		$cnt = $cnt + 1;
	}
	
	$key_vals_array = get_values_Keys($least_cnt, $from_val, $to_val, $keys, $rows);
  
  echo json_encode($key_vals_array);

  mysqli_close($con);
?>