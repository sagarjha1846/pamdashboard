
<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';

if(isset($_POST['machinename']) && $_POST['machinename'] != '' )
{
    
    
    $id = $_POST['machinename'];
    
    if($id == '1'){
        
        $query = "
        SELECT * FROM tableheader WHERE ID = $id
        ";
        
        $sql = "";
        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        $sql = "
          SELECT * FROM productiondetail WHERE status = $id 
        ";

        if(isset($_POST["from_date"], $_POST["to_date"]))  
         {  

              $sql .= "  

                   AND Date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
              ";  

        }

        if(isset( $_POST['customer']))
        {
         if($_POST['customer'] != 'all'){

                $sql .= '
               AND customer = "'.$_POST['customer'].'" 
             ';

            }

            if($_POST['customer'] == 'all'){

                $sql .= '

             ';

            } 
        }

        if(isset( $_POST['machine']))
        {
            if($_POST['machine'] != 'all'){

                $sql .= '
               AND machine = "'.$_POST['machine'].'" 
             ';

            }

            if($_POST['machine'] == 'all'){

                $sql .= '

             ';

            }


        }


        if(isset( $_POST['cytype']))
        {
            if($_POST['cytype'] != 'all'){

                $sql .= '
               AND cylindertype = "'.$_POST['cytype'].'" 
             ';

            }

            if($_POST['cytype'] == 'all'){

                $sql .= '

             ';

            }


        }


        if(isset( $_POST['cystatus']))
        {
            if($_POST['cystatus'] != 'all'){

                $sql .= '
               AND cylinderstatus = "'.$_POST['cystatus'].'" 
             ';

            }

            if($_POST['cystatus'] == 'all'){

                $sql .= '

             ';

            }


        }


        if(isset( $_POST['net']))
        {
            if($_POST['net'] != 'all'){

                $sql .= '
               AND net = "'.$_POST['net'].'" 
             ';

            }

            if($_POST['net'] == 'all'){

                $sql .= '

             ';

            }


        }


        if(isset( $_POST['res']))
        {
            if($_POST['res'] != 'all'){

                $sql .= '
               AND residual = "'.$_POST['res'].'" 
             ';

            }

            if($_POST['res'] == 'all'){

                $sql .= '

             ';

            }


        }

        $statement = $connect->prepare($sql);

        $statement->execute();

        $results = $statement->fetchAll();

        $row = $statement->rowCount();

        $output .= '  
                    <table class="table table-responsive table-bordered table-hover scroll" id="tblexportData">  
                    <thead class="thead-dark">
                    ';  


        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <tr>
                <th width ="24">'.$row["header1"].'</th>
                <th width="8%">'.$row["header2"].'</th>
                <th width="8%">'.$row["header3"].'</th>
                <th width="8%">'.$row["header4"].'</th>
                <th width="8%">'.$row["header5"].'</th>
                <th width="8%">'.$row["header6"].'</th>
                <th width="8%">'.$row["header7"].'</th>
                <th width="8%">'.$row["header8"].'</th>
                <th width="8%">'.$row["header9"].'</th>
                <th width="10%">'.$row["header10"].'</th>

                </tr>
                ';
            }

        }



        $output .= '
        </thead>
        '; 

        if($row > 0)
        {

            foreach($results as $row)
                
            {
                $output .= '
                <tr>
                <td>'.$row["Date"].'</td>
                <td>'.$row["tare"].'</td>
                <td>'.$row["net"].'</td>
                <td>'.$row["residual"].'</td>
                <td>'.$row["differences"].'</td>
                <td>'.$row["gas"].'</td>
                <td>'.$row["machine"].'</td>
                <td>'.$row["cylinderstatus"].'</td>
                <td>'.$row["cylindertype"].'</td>
                <td>'.$row["customer"].'</td>

                 </tr>
                ';
            
            }
            
        }
        
        else{
           
            $output .= '
                        <tr>
                        <td>No Data Found</td>
                        </tr>
                        '; 
        }

        $output .= '
        <tbody>
        </tbody>   
        <table>
        
        ';




    }
    
}
    

echo $output;





?>

