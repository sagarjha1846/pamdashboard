<?php

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';

if(isset($_POST['machinename']) && $_POST['machinename'] != '' )
{
   
    $id = $_POST['machinename'];
    
    if($id == '1'){
        
        $query = "
        SELECT * FROM tableheader WHERE ID = $id
        ";
        
        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        $sql = "";

        if(isset($_POST['limit']))  
        {
            
            $limit = $_POST['limit'];

            $sql = "
            SELECT * FROM productiondetail_live WHERE status = $id ORDER BY Date DESC LIMIT $limit
            ";

        }


        $statement = $connect->prepare($sql);

        $statement->execute();

        $results = $statement->fetchAll();

        $row = $statement->rowCount();

        $output .= '  
                    <table class="table table-responsive table-bordered table-hover scroll" id="tblexportData">  
                    <thead class="thead-dark">
                    ';  


        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <tr>
                <th width ="20%">'.$row["header1"].'</th>
                <th width="8%">'.$row["header2"].'</th>
                <th width="8%">'.$row["header3"].'</th>
                <th width="8%">'.$row["header4"].'</th>
                <th width="8%">'.$row["header5"].'</th>
                <th width="10%">'.$row["header6"].'</th>
                <th width="10%">'.$row["header7"].'</th>
                <th width="10%">'.$row["header8"].'</th>
                <th width="10%">'.$row["header9"].'</th>
                <th width="15%">'.$row["header10"].'</th>
                 </tr>
                ';
            }

        }



        $output .= '
        </thead>
        '; 

        if($row > 0)
        {

            foreach($results as $row)
                
            {
                $output .= '
                <tr>
                <td>'.$row["Date"].'</td>
                <td>'.$row["tare"].'</td>
                <td>'.$row["net"].'</td>
                <td>'.$row["residual"].'</td>
                <td>'.$row["differences"].'</td>
                <td>'.$row["gas"].'</td>
                <td>'.$row["machine"].'</td>
                <td>'.$row["cylinderstatus"].'</td>
                <td>'.$row["cylindertype"].'</td>
                <td>'.$row["customer"].'</td>
                </tr>
                ';
            
            }
            
        }

        $output .= '
        <tbody>
        </tbody>   
        <table>
        
        ';




    }
    
    else if($id == '2' || $id == '3'){
        
        $query = "
        SELECT * FROM tableheader WHERE ID = $id
        ";
        
        
        
        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        $sql = "
        ";

        if(isset($_POST['limit']))  
        {
            
            $limit = $_POST['limit'];

            $sql = "
            SELECT * FROM productiondetail WHERE status = $id ORDER BY Date DESC LIMIT $limit
            ";

        }


        $statement = $connect->prepare($sql);

        $statement->execute();

        $results = $statement->fetchAll();

        $row = $statement->rowCount();

        $output .= '  
                    <table class="table table-responsive table-bordered table-hover scroll" id="tblexportData">  
                    <thead class="thead-dark">
                    ';  


        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <tr>
                <th width ="30%">'.$row["header1"].'</th>
                <th width="10%">'.$row["header2"].'</th>
                <th width="10%">'.$row["header3"].'</th>
                <th width="15%">'.$row["header4"].'</th>
                <th width="15%">'.$row["header5"].'</th>
                <th width="15%">'.$row["header6"].'</th>
                <th width="15%">'.$row["header7"].'</th>  
                </tr>
                ';
            }

        }



        $output .= '
        </thead>
        '; 

        if($row > 0)
        {

            foreach($results as $row)
                
            {
                $output .= '
                <tr>
                <td>'.$row["Date"].'</td>
                <td>'.$row["tare"].'</td>
                <td>'.$row["net"].'</td>
                <td>'.$row["residual"].'</td>
                <td>'.$row["differences"].'</td>
                <td>'.$row["gas"].'</td>
                <td>'.$row["machine"].'</td>
                </tr>
                ';
            
            }
            
        }

        $output .= '
        <tbody>
        </tbody>   
        <tfoot class="thead-dark">
        '; 

        if($total_row > 0)
        {
            
            foreach($result as $row)
                
            {
                $output .= '
                
                <tr>
                <th width ="30%">'.$row["header1"].'</th>
                <th width="10%">'.$row["header2"].'</th>
                <th width="10%">'.$row["header3"].'</th>
                <th width="15%">'.$row["header4"].'</th>
                <th width="15%">'.$row["header5"].'</th>
                <th width="15%">'.$row["header6"].'</th>
                <th width="15%">'.$row["header7"].'</th>   
                </tr>
                ';
                
            }

        }

        $output .= '
        </tfoot> 
        <table>
        
        ';




    }
    
    else if($id == '4' || $id == '5' || $id == '6'){
        
        $query = "
        SELECT * FROM tableheader WHERE ID = $id
        ";
        
        
        
        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        $sql = "
        
        ";

        if(isset($_POST['limit']))  
        {
            
            $limit = $_POST['limit'];

            $sql = "
            SELECT * FROM productiondetail WHERE status = $id ORDER BY Date DESC LIMIT $limit
            ";

        }


        $statement = $connect->prepare($sql);

        $statement->execute();

        $results = $statement->fetchAll();

        $row = $statement->rowCount();

        $output .= '  
                    <table class="table table-responsive table-bordered table-hover scroll" id="tblexportData">  
                    <thead class="thead-dark">
                    ';  


        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <tr>
                <th width ="30">'.$row["header1"].'</th>
                <th width="9%">'.$row["header2"].'</th>
                <th width="9%">'.$row["header3"].'</th>
                <th width="9%">'.$row["header4"].'</th>
                <th width="9%">'.$row["header5"].'</th>
                <th width="9%">'.$row["header6"].'</th>
                <th width="9%">'.$row["header7"].'</th>
                <th width="9%">'.$row["header8"].'</th>
                <th width="9%">'.$row["header9"].'</th>
                </tr>
                ';
            }

        }



        $output .= '
        </thead>
        '; 

        if($row > 0)
        {

            foreach($results as $row)
                
            {
                $output .= '
                <tr>
                <td>'.$row["Date"].'</td>
                <td>'.$row["tare"].'</td>
                <td>'.$row["net"].'</td>
                <td>'.$row["residual"].'</td>
                <td>'.$row["differences"].'</td>
                <td>'.$row["gas"].'</td>
                <td>'.$row["machine"].'</td>
                <td>'.$row["cylinderstatus"].'</td>
                <td>'.$row["cylindertype"].'</td>
                </tr>
                ';
            
            }
            
        }

        $output .= '
        <tbody>
        </tbody>   
        <tfoot class="thead-dark">
        '; 

        if($total_row > 0)
        {
            
            foreach($result as $row)
                
            {
                $output .= '
                
                <tr>
                <th>'.$row["header1"].'</th>
                <th>'.$row["header2"].'</th>
                <th>'.$row["header3"].'</th>
                <th>'.$row["header4"].'</th>
                <th>'.$row["header5"].'</th>
                <th>'.$row["header6"].'</th>
                <th>'.$row["header7"].'</th>
                <th>'.$row["header8"].'</th>
                <th>'.$row["header9"].'</th>
               </tr>
                ';
                
            }

        }

        $output .= '
        </tfoot> 
        <table>
        
        ';




    }
    
    else{
        
        $query = "
        SELECT * FROM tableheader WHERE ID = 1
        ";
        
        
        
        $statement = $connect->prepare($query);

        $statement->execute();

        $result = $statement->fetchAll();

        $total_row = $statement->rowCount();

        $sql = "
        
        ";

        if(isset($_POST['limit']))  
        {
            
            $limit = $_POST['limit'];

            $sql = "
            SELECT * FROM productiondetail WHERE status = 1 ORDER BY Date DESC LIMIT $limit
            ";

        }


        $statement = $connect->prepare($sql);

        $statement->execute();

        $results = $statement->fetchAll();

        $row = $statement->rowCount();

        $output .= '  
                    <table class="table table-responsive table-bordered table-hover scroll" id="tblexportData">  
                    <thead class="thead-dark">
                    ';  


        if($total_row > 0)
        {
            
            foreach($result as $row)

            {
                $output .= '
                <tr>
                <th width ="20">'.$row["header1"].'</th>
                <th width="10%">'.$row["header2"].'</th>
                <th width="10%">'.$row["header3"].'</th>
                <th width="10%">'.$row["header4"].'</th>
                <th width="10%">'.$row["header5"].'</th>
                <th width="10%">'.$row["header6"].'</th>
                <th width="10%">'.$row["header7"].'</th>
                <th width="10%">'.$row["header8"].'</th>
                <th width="10%">'.$row["header9"].'</th>
                </tr>
                ';
            }

        }



        $output .= '
        </thead>
        '; 

        if($row > 0)
        {

            foreach($results as $row)
                
            {
                $output .= '
                <tr>
               <th width ="20">'.$row["header1"].'</th>
                <th width="10%">'.$row["header2"].'</th>
                <th width="10%">'.$row["header3"].'</th>
                <th width="10%">'.$row["header4"].'</th>
                <th width="10%">'.$row["header5"].'</th>
                <th width="10%">'.$row["header6"].'</th>
                <th width="10%">'.$row["header7"].'</th>
                <th width="10%">'.$row["header8"].'</th>
                <th width="10%">'.$row["header9"].'</th>
                </tr>
                ';
            
            }
            
        }

        $output .= '
        <tbody>
        </tbody>    
        <table>
        
        ';
  
    }
  


}

    

echo $output;





?>