<?php  
 
$connect = mysqli_connect("localhost", "root", "", "plcproject");  

if(isset($_POST["cystatus"],$_POST["cystatus_code"])){
  
    $sql = "INSERT INTO `cylinderstatus`( `CODE`, `CYSTATUS`) VALUES ('".$_POST["cystatus_code"]."', '".$_POST["cystatus"]."')";  
    
    
if(mysqli_query($connect, $sql))  

{  

    echo 'Data Inserted';  

}

}
  

?> 