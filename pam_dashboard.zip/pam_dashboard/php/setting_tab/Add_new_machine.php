<?php  

$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';  

$sql = "SELECT * FROM tableheader ORDER BY id ASC";  
$statement = $connect->prepare($sql);
$statement->execute();
$results = $statement->fetchAll();
$row = $statement->rowCount();

 
 $output .= '  
            <div class="table-responsive">  
            <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>  
            <th width="10%">ID</th>  
            <th width="30%">MACHINE TYPE</th>
            <th width="30%">STATUS</th>  
            </tr>
            </thead>'; 

if($row > 0)
{

    foreach($results as $row)

    {
           $output .= '  
                <tr>  
                <td>'.$row["ID"].'</td>  
                <td contenteditable class="enable_machine" data-id="'.$row["ID"].'" data-column="machinename">'.$row["machinename"].'</td>
                <td contenteditable class="enable_machine" data-id="'.$row["ID"].'" data-column="status">'.$row["status"].'</td>
                </tr>  
           ';  
      }  
      
 }  
 else  
 {  
      $output .= '<tr>  
                    <td colspan="4">Data not Found</td>  
                    </tr>';  
 }  
 $output .= ' 
                </table>  
      </div>';  
 echo $output;  
 ?>