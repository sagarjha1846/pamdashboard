<?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 $sql = "DELETE FROM cylindertype WHERE ID = '".$_POST["id"]."'";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Data Deleted';  
 }  
 ?>