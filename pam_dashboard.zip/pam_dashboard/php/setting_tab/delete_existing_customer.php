<?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 $sql = "DELETE FROM customerdetail WHERE id = '".$_POST["deletedata"]."'";  
 if(mysqli_query($connect, $sql))  
 {  
      echo 'Data Deleted';  
 }  
 ?>