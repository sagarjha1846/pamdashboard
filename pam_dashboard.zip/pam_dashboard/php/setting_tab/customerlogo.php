 <?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 if(isset($_POST["insert_customer"]))  
 {  
     $file = base64_encode(file_get_contents($_FILES["image"]["tmp_name"])); 
     
      $query = "INSERT INTO customer(LOGO) VALUES ('$file')";  
      if(mysqli_query($connect, $query))  
      {  
           echo '<script>alert("Image Inserted into Database")</script>';  
      }  
 }  
 ?> 