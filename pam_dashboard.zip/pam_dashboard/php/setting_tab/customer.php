<?php  
$connect = new PDO("mysql:host=localhost;dbname=plcproject", "root", "");

$output = '';  

$sql = "SELECT * FROM customer ORDER BY id ASC";  
$statement = $connect->prepare($sql);
$statement->execute();
$results = $statement->fetchAll();
$row = $statement->rowCount();

 
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">
           <thead class="thead-dark">
           <tr>  
           <th width="10%">ID</th>  
           <th width="10%">CODE</th>  
           <th width="30%">DESC</th>
           <th width="10%">DELETE</th>  
           </tr>
           </thead>'; 

if($row > 0)
{

    foreach($results as $row)

    {
           $output .= '  
                <tr>  
                     <td>'.$row["ID"].'</td>  
                     <td contenteditable class="edit_datas" data-id="'.$row["ID"].'" data-column="code">'.$row["CODE"].'</td>  
                     <td contenteditable class="edit_datas" data-id="'.$row["ID"].'" data-column="customer">'.$row["CUSTOMER"].'</td>
                      <td><button type="button" name="delete_btn" data-id3="'.$row["ID"].'" class="btn-xs btn-danger delete_customer">x</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="customer_code" contenteditable></td>  
                <td id="customer_name" contenteditable></td> 
                <td><button type="button" name="btn_add" id="insert_customer" class="btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= ' 
                </table>  
      </div>';  
 echo $output;  
 ?>