<?php

$connect = mysqli_connect("localhost", "root", "", "plcproject");

if(isset($_POST["histogramlimit"]))
{             

$sql = "UPDATE `othersettings` SET `histogramlimit`='".$_POST["histogramlimit"]."' WHERE 1";
    
    
if(mysqli_query($connect, $sql))  

{  

    echo 'Data Updated';  

}  

}
?>