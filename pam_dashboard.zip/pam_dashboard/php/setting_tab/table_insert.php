
<?php
$connect = mysqli_connect("localhost", "root", "", "plcproject");
if(isset($_POST["machinename"], $_POST["quantity"],$_POST["plcaddress"], $_POST["plcslug"],$_POST["header1"], $_POST["header2"],$_POST["header7"], $_POST["header3"],$_POST["header8"], $_POST["header4"],$_POST["header9"], $_POST["header5"],$_POST["header10"], $_POST["header6"],$_POST["projectheading"]))
{
 
    $machinename = mysqli_real_escape_string($connect, $_POST["machinename"]);

    $quantity = mysqli_real_escape_string($connect, $_POST["quantity"]);
 
    $plcaddress = mysqli_real_escape_string($connect, $_POST["plcaddress"]);
    
    $plcslug = mysqli_real_escape_string($connect, $_POST["plcslug"]);
    
    $header1 = mysqli_real_escape_string($connect, $_POST["header1"]);
    $header2 = mysqli_real_escape_string($connect, $_POST["header2"]);
    $header3 = mysqli_real_escape_string($connect, $_POST["header3"]);
    $header4 = mysqli_real_escape_string($connect, $_POST["header4"]);
    $header5 = mysqli_real_escape_string($connect, $_POST["header5"]);
    $header6 = mysqli_real_escape_string($connect, $_POST["header6"]);
    $header7 = mysqli_real_escape_string($connect, $_POST["header7"]);
    $header8 = mysqli_real_escape_string($connect, $_POST["header8"]);
    $header9 = mysqli_real_escape_string($connect, $_POST["header9"]);
    $header10 = mysqli_real_escape_string($connect, $_POST["header10"]);
    
    $projectheading = mysqli_real_escape_string($connect, $_POST["projectheading"]);



    $query = "INSERT INTO `tableheader`( `machinename`, `quantity`, `plcaddress`, `plcslug`, `header1`, `header2`, `header3`, `header4`, `header5`, `header6`, `header7`, `header8`, `header9`, `header10`, `projectheading`) VALUES ('$machinename','$quantity','$plcaddress','$plcslug','$header1','$header2','$header3','$header4','$header5','$header6','$header7','$header8','$header9','$header10','$projectheading')";
 
    if(mysqli_query($connect, $query))
     {
      echo 'Data Inserted';
     }

}
?>