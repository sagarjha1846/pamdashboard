<?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 $output = '';  
 $sql = "SELECT * FROM machine ORDER BY id ASC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered"> 
            <thead class="thead-dark">
                <tr>  
                     <th  width="10%">ID</th> 
                     <th  width="10%">CODE</th> 
                     <th  width="15%">START ADDRESS</th>  
                     <th  width="15%">FLAG ADDRESS</th>  
                     <th  width="10%">QUANTITY</th>  
                     <th  width="10%">STATUS</th>       
                     <th  width="15%">MACHINE</th>
                     <th  width="15%">DELETE</th>  
                </tr>
                
                </thead>
               ';  
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                 <tbody>
                    <tr>  
                       
                       <td>'.$row["ID"].'</td> 
                       
                       <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="code">'.$row["CODE"].'</td>  
                    
                        <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="startaddress">'.$row["STARTADDRESS"].'</td>  
                     
                       <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="flagaddress">'.$row["FLAGADDRESS"].'</td> 
                       
                       <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="quantity">'.$row["QUANTITY"].'</td>  
                       
                       <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="status">'.$row["STATUS"].'</td> 
                       
                       <td contenteditable class="edit" data-id="'.$row["ID"].'" data-column="machine">'.$row["MACHINE"].'</td> 
                       
                       <td><button type="button" name="delete_btn" data-id7="'.$row["ID"].'" class="btn-xs btn-danger btn_delete">x</button></td>  
                
                </tr> 
                    </tbody>
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                
                <td id="machine_code" contenteditable></td>  
                
                <td id="start_address" contenteditable></td>  
                
                <td id="flag_address" contenteditable></td>  
                
                <td id="quantity" contenteditable></td> 
                
                <td id="machine_status" contenteditable></td> 
            
                <td id="machine_name" contenteditable></td> 
                
                <td><button type="button" name="btn_add" id="btn_add" class="btn-xs btn-success">+</button> </td>  
           
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= '
                </table>  
      </div>';  
 echo $output;  
 ?>