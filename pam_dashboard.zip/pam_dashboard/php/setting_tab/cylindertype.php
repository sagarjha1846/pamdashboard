<?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 $output = '';  
 $sql = "SELECT * FROM cylindertype ORDER BY ID ASC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">
           <thead class="thead-dark">
           <tr>  
           <th width="10%">ID</th>  
           <th width="40%">CODE</th>  
           <th width="40%">DESC</th>  
           <th width="10%">DELETE</th>  
           </tr>
           </thead>'; 
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["ID"].'</td>  
                     <td contenteditable class="update" data-id="'.$row["ID"].'" data-column="code">'.$row["CODE"].'</td>  
                     <td contenteditable class="update" data-id="'.$row["ID"].'" data-column="cytype">'.$row["CYTYPE"].'</td>  
                     <td><button type="button" name="delete_cytype" data-id10="'.$row["ID"].'" class="btn-xs btn-danger delete_cytype">x</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="cytype_code" contenteditable></td>  
                <td id="cytype" contenteditable></td>  
                <td><button type="button" name="insert_cytype" id="insert_cytype" class="btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= ' 
                </table>  
      </div>';  
 echo $output;  
 ?>