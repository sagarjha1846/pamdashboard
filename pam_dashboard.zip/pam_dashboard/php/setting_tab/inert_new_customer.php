
<?php

$connect = mysqli_connect("localhost", "root", "", "plcproject");


$sql = "INSERT INTO `customerdetail`(`CustomerName`, `CustomerLogo`) VALUES ('".$_POST["customer"]."', '".$_POST["file_name"]."')";  

if(mysqli_query($connect, $sql))  

{  

    echo 'Data Inserted';  

}  

?> 
