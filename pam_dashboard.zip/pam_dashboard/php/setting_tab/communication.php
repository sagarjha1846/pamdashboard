<?php

$connect = mysqli_connect("localhost", "root", "", "plcproject");

if(isset($_POST["commid"], $_POST["Baudrate"],$_POST["Parity"], $_POST["Databit"],$_POST["Stopbit"]))
{             


$sql = "UPDATE `set_comm` SET `COMMUNICATION`='".$_POST["commid"]."',`BAUDRATE`='".$_POST["Baudrate"]."',`PARITY`='".$_POST["Parity"]."',`DATABIT`='".$_POST["Databit"]."',`STOPBIT`='".$_POST["Stopbit"]."' WHERE 1";
    
    
if(mysqli_query($connect, $sql))  

{  

    echo 'Data Updated';  

}  

}
?>