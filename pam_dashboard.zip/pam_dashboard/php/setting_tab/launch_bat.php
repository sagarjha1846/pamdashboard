<?php

if(isset($_POST['action']) && $_POST['action'] == 'action' )
{   
    $cmd="start c:\WINDOWS\system32\cmd.exe /c C:/xampp/htdocs/pam_dashboard/api/stop_modbus.bat";
    print($cmd);
    exec($cmd, $output);
	//exec('c:\WINDOWS\system32\cmd.exe /c START api\stop_modbus.bat'); //file path
	//exec("start c:\WINDOWS\system32\cmd.exe /c start_dashboard_app.bat", $output); //file path
	
}

?>
