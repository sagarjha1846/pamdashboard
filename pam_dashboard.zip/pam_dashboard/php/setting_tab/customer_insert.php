<?php  
 
$connect = mysqli_connect("localhost", "root", "", "plcproject"); 

$sql = "INSERT INTO `customer`( `CODE`, `CUSTOMER`) VALUES ('".$_POST["code"]."', '".$_POST["desc"]."')";  


    if(mysqli_query($connect, $sql))  

    {  

        echo 'Data Inserted';  

    } 
    


?> 