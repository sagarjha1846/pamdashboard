
<?php

$connect = mysqli_connect("localhost", "root", "", "plcproject");


$sql = "INSERT INTO `tableheader`( `Code`, `machinename`, `status`) VALUES ('".$_POST["machine_code"]."', '".$_POST["machine_type"]."','".$_POST["status"]."')";  

if(mysqli_query($connect, $sql))  

{  

    echo 'Data Inserted';  

}  

?> 
