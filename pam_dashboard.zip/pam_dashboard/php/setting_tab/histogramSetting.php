<?php

$connect = mysqli_connect("localhost", "root", "", "plcproject");

if(isset($_POST["leastCount"], $_POST["rangeTo"],$_POST["rangeFrom"]))
{             

$sql = "UPDATE `othersettings` SET `rangefrom`='".$_POST["rangeFrom"]."',`rangeto`='".$_POST["rangeTo"]."',`leastcount`='".$_POST["leastCount"]."' WHERE 1";
    
    
if(mysqli_query($connect, $sql))  

{  

    echo 'Data Updated';  

}  

}
?>