<?php  
 $connect = mysqli_connect("localhost", "root", "", "plcproject");  
 $output = '';  
 $sql = "SELECT * FROM tableheader ORDER BY id ASC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      
           <table class="table pro_table"> 
            <thead class="thead-dark">
                <tr>  
                     <th>ID</th> 
                     <th>MACHINE NAME</th> 
                     <th>SLAVE ID</th> 
                     <th>QUANTITY</th> 
                     <th>PLC ADDRESS</th>  
                     <th>PLC FLAG</th>
                     <th>STATUS</th>
                     <th>PROJECT HEADER</th>
                     <th>MACHINE ID</th> 
                     <th>DB NAME</th> 
                     <th>HEADER 1</th>
                     <th>HEADER 2</th>
                     <th>HEADER 3</th>
                     <th>HEADER 4</th>
                     <th>HEADER 5</th>
                     <th>HEADER 6</th>
                     <th>HEADER 7</th>
                     <th>HEADER 8</th>
                     <th>HEADER 9</th>
                     <th>HEADER 10</th>
					 <th>HEADER 11</th>
					 <th>HEADER 12</th>
					 <th>HEADER 13</th>
					 <th>HEADER 14</th>
					 <th>HEADER 15</th>
                     <th>DELETE</th>  
                </tr>
                </thead>
                ';  
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
           <tbody>
           <tr>  
            <td>'.$row["ID"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="machinename">'.$row["machinename"].'</td>         
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="slaveid">'.$row["slaveid"].'</td>  
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="quantity">'.$row["quantity"].'</td>  
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="plcaddress">'.$row["plcaddress"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="plcflagaddr">'.$row["plcflagaddr"].'</td>  
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="status">'.$row["status"].'</td>  
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="projectheading">'.$row["projectheading"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="mcid">'.$row["mcid"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="dbname">'.$row["dbname"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header1">'.$row["header1"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header2">'.$row["header2"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header3">'.$row["header3"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header4">'.$row["header4"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header5">'.$row["header5"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header6">'.$row["header6"].'</td>
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header7">'.$row["header7"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header8">'.$row["header8"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header9">'.$row["header9"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header10"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header11"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header12"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header13"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header14"].'</td> 
            <td contenteditable class="update_table" data-id="'.$row["ID"].'" data-column="header10">'.$row["header15"].'</td> 
            <td><button type="button" name="delete_header" data-id116="'.$row["ID"].'" class="btn-xs btn-danger delete_header">x</button></td>  
            </tr> 
            </tbody>
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="machinename" contenteditable></td>  
                <td id="slaveid" contenteditable></td>  
                <td id="quantity" contenteditable></td>  
                <td id="plcaddress" contenteditable></td>  
                <td id="plcflagaddr" contenteditable></td> 
                <td id="status" contenteditable></td> 
                <td id="projectheading" contenteditable></td> 
                <td id="mcid" contenteditable></td>  
                <td id="dbname" contenteditable></td>  
                <td id="header1" contenteditable></td> 
                <td id="header2" contenteditable></td>  
                <td id="header3" contenteditable></td>  
                <td id="header4" contenteditable></td>  
                <td id="header5" contenteditable></td> 
                <td id="header6" contenteditable></td> 
                <td id="header7" contenteditable></td>  
                <td id="header8" contenteditable></td>  
                <td id="header9" contenteditable></td>  
                <td id="header10" contenteditable></td> 
                <td id="header11" contenteditable></td> 
                <td id="header12" contenteditable></td> 
                <td id="header13" contenteditable></td> 
                <td id="header14" contenteditable></td> 
                <td id="header15" contenteditable></td> 
                <td><button type="button" name="add_header" id="add_header" class="btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= '
                </table>  
      ';  
 echo $output;  
 ?>