<?php  
 
$connect = mysqli_connect("localhost", "root", "", "plcproject");  

$sql = "INSERT INTO `cylindertype`( `CODE`, `CYTYPE`) VALUES ('".$_POST["cytype_code"]."', '".$_POST["cytype"]."')";  

if(mysqli_query($connect, $sql))  

{  

    echo 'Data Inserted';  

}  

?> 