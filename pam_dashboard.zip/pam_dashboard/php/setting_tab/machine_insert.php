<?php  
 
$connect = mysqli_connect("localhost", "root", "", "plcproject");  

$sql = "INSERT INTO `machine`( `CODE`, `STARTADDRESS`, `FLAGADDRESS`, `QUANTITY`,`STATUS`, `MACHINE`) VALUES ('".$_POST["code"]."', '".$_POST["start"]."','".$_POST["flag"]."', '".$_POST["quantity"]."','".$_POST["machine_status"]."','".$_POST["machine"]."')";  

if(mysqli_query($connect, $sql))  

{  

    echo 'Data Inserted';  

}  

?> 