<?php
	$output = shell_exec("pythonw modbus_scan_new.pyc > NUL &");
    echo $output;
?>
