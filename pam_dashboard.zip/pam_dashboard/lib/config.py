# ======================================================================
# File:			config.py
# Purpose:	  	Holds some of the config parameters used for Modbus communications
# Inputs:	   	None
# Owner: 		Sudesh Sawant
# Copy Rights: 	@Xargs
# Notes:		17-Jun-2020 : Created By SYS.
# ======================================================================

COMMAND = 'START'


#Create Logger for logging messages
import logging

# Gets or creates a logger
logger = logging.getLogger(__name__)  

# set log level
logger.setLevel(logging.INFO)

# define file handler and set formatter
file_handler = logging.FileHandler('dashboard_exec.log')
formatter    = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(formatter)

# add file handler to logger
logger.addHandler(file_handler)

#Enable DEBUG MSG
DEBUG_MSG = 1

#Engineering conversion for Raw vaues from MODBUS
prod_data = {1: ['Date', 'tare', 'net', 'residual', 'differences', 'gas', 'cylinderstatus', 'cylindertype', 'machine', 'customer', 'status'], 16: ['Date', 'OkCylinder', 'RejCylinder', 'RejCode', 'FlagAddress', 'status']}

slave_engg_conv = 	{ 
					1: {'date':1, 'tare': 0.1, 'net': 0.1, 'residual': 0.1, 'differences': 1, 'gas': 0.1, 'cylinderstatus': 1, 'cylindertype': 1, 'machine': 1, 'customer': 1, 'header11': 1, 'header12': 1, 'header13': 1, 'header14': 1, 'header15': 1}, 
					2: {'okcyl': 1, 'rejcyl': 1, 'cylperhr': 1, 'header4': 0.1, 'header5': 1, 'header6': 1, 'header7': 1, 'header8': 1, 'header9': 1, 'header10': 1, 'header11': 1, 'header12': 1, 'header13': 1, 'header14': 1, 'header15': 1}, 
					3: {'okcyl': 1, 'rejcyl': 1, 'cylperhr': 1, 'header4': 0.1, 'header5': 1, 'header6': 1, 'header7': 1, 'header8': 1, 'header9': 1, 'header10': 1, 'header11': 1, 'header12': 1, 'header13': 1, 'header14': 1, 'header15': 1}, 
					4: {'header1': 1, 'header2': 0.1, 'header3': 0.1, 'header4': 0.1, 'header5': 1, 'header6': 1, 'header7': 1, 'header8': 1, 'header9': 1, 'header10': 1, 'header11': 1, 'header12': 1, 'header13': 1, 'header14': 1, 'header15': 1} 
					}
					
#Customer_Id, FM_No, Type_Cy, Residual_Gas, Tare_Weight, Net_Weight, Difference, CyFilling_Status, Data_Read_Bit, Date, Month, Year, Hours, Minutes, Seconds, LPG_PRESSURE

#Date, `tare`, `net`, `residual`, `differences`, `gas`, `cylinderstatus`, `cylindertype`, `machine`, `customer`
#OK cylinder, Rej cylinder, Cylinder per hours, Data Read PLC Bit, Spare


slave_reg_hdr_map = 	{ 
					1: {'Date': 'date', 'tare': 'reg5', 'net': 'reg6', 'residual': 'reg4', 'differences': 'reg7', 'gas': 'reg16', 'cylinderstatus': 'reg8', 'cylindertype': 'reg3', 'machine': 'reg2', 'customer': 'reg1'}, 
					2: {'okcyl': 'reg1', 'rejcyl': 'reg2', 'cylperhr': 'reg3', 'spare1': 'reg4', 'spare2': 'reg5', 'spare3': 'reg6'}, 
					3: {'okcyl': 'reg1', 'rejcyl': 'reg2', 'cylperhr': 'reg3', 'spare1': 'reg4', 'spare2': 'reg5', 'spare3': 'reg6'}, 
					4: {'header1': 'reg1', 'header2': 'reg2', 'header3': 'reg3', 'header4': 'reg4', 'header5': 'reg5', 'header6': 'reg6', 'header7': 'reg7', 'header8': 'reg8', 'header9': 'reg9', 'header10': 'reg10', 'header11': 'reg11', 'header12': 'reg12', 'header13': 'reg13', 'header14': 'reg14', 'header15': 'reg15'} 
					}

reg_list = ['reg1', 'reg2', 'reg3', 'reg4', 'reg5', 'reg6', 'reg7', 'reg8', 'reg9', 'reg10', 'reg11', 'reg12', 'reg13', 'reg14', 'reg15', 'reg16', 'reg17', 'reg18', 'reg19', 'reg20'] 
					
CYLINDER_TYPE = {1 : 'Top Entry', 2 : 'Base Entry'}
CYLINDER_STATUS = {0 : 'Error', 1 : 'Pass', 2 : 'Under Fill', 3 : 'Over Fill'}

#OLD VLD config
rejCode = {1:'Oring Leak', 3:'Valve Leak'}


# Delay between two requests.
INTER_REQUEST_DELAY = 0.5
SERIAL_CHECK_CNT = 6


#OK_cylinder, Rej_cylinder, Cylinder_per_hours, Data_Read_Bit, Spare

fm01_dbupdate_sql = "INSERT INTO data_base (Date, `tare`, `net`, `residual`, `differences`, `gas`, `cylinderstatus`, `cylindertype`, `machine`, `customer`, `status`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"


oldvld_dbupdate_sql = "INSERT INTO data_base (Date, `OkCylinder`, `RejCylinder`, `RejCode`, `FlagAddress`, `status`) VALUES (%s, %s, %s, %s, %s, %s)"

old01_dbupdate_sql = "UPDATE vld_and_old SET OkCylinder = %s, RejCylinder = %s, ProductionRate = %s WHERE id = 2"

vld01_dbupdate_sql = "UPDATE vld_and_old SET OkCylinder = %s, RejCylinder = %s, ProductionRate = %s WHERE id = 1"

comm_status_update_sql = "UPDATE data_base SET STATUSBIT = %s WHERE id = 1"

#prod_rate_sql = "select count(*) from data_base where Date>= NOW()- INTERVAL 1 HOUR"

prod_rate_sql = "select * from  data_base where Date >= DATE_SUB(NOW(),INTERVAL 1 HOUR)"

get_all_prod_items_sql = "SELECT * FROM data_base WHERE status = 1"

get_all_diff_sql = "SELECT differences FROM data_base WHERE status = 1"

prodrate_update_sql = "UPDATE data_base SET ProductionRate = %s, CylinderChecked = %s, AcceptedCylinder = %s, AcceptedCylinderPerc = %s, UnderFilledCylinder = %s, OverFilledCylinder = %s WHERE id = 1"

slave_sql_cmds = {1 : fm01_dbupdate_sql, 16: oldvld_dbupdate_sql, 3: vld01_dbupdate_sql}

get_all_oldvld_items_sql = "SELECT * FROM data_base"
get_old_ok_sql = "SELECT OkCylinder FROM vld_and_old WHERE id = 2"
get_vld_ok_sql = "SELECT OkCylinder FROM vld_and_old WHERE id = 1"
get_old_rej_sql = "SELECT RejCylinder FROM vld_and_old WHERE id = 2"
get_vld_rej_sql = "SELECT RejCylinder FROM vld_and_old WHERE id = 1"
get_old_prodrate_sql = "SELECT ProductionRate FROM vld_and_old WHERE id = 2"
get_vld_prodrate_sql = "SELECT ProductionRate FROM vld_and_old WHERE id = 1"


