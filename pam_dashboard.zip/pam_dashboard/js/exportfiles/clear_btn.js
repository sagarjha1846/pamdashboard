$(document).ready(function(){
    
    $('#clearTable').click(function(){
        
        let clear = '1';
        
        $.ajax({

            type: "POST",

            //url: "clear.php",
            url:"http://localhost/pam_dashboard/php/export/clear.php",  

            data:{clear:clear}, 

            success: function (data) {

                alert(data); 

            }

        });
    })
    
    
    $('#clearTable2').click(function(){
        
        let clear = '1';
        
        $.ajax({

            type: "POST",

            //url: "clear.php",
            url:"http://localhost/pam_dashboard/php/export/clear.php",  

            data:{clear:clear}, 

            success: function (data) {

                alert(data); 

            }

        });
    })
    
})