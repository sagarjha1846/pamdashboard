$(document).ready(function(){
    
    $('#set_commu').click(function(){
        
        var commid =  $('#Comm').val();
        
        var Baudrate =  $('#Baudrate').val();

        var Parity =  $('#Parity').val();

        var Databit =  $('#Databit').val();
        
        var Stopbit =  $('#Stopbit').val();

        
        $.ajax({  
        
            url:"http://localhost/pam_dashboard/php/setting_tab/communication.php",  
            
            method:"POST",  
            
            data:{
            
                commid:commid,
            
                Baudrate:Baudrate,
            
                Parity:Parity,
                
                Databit:Databit,
                
                Stopbit:Stopbit
            
            },
            
            success:function(data){
                
                alert(data);
            }
            
        })
    })
})
