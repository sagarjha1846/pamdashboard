
// Setting
 //sign in setting      
            


$("#submitButton").click(function() {

var errorMessage = "";
var fieldsMissing = "";

    if ($("#password").val() == "") {

        fieldsMissing += "<br>Password";

    }



    if (fieldsMissing != "") {

        errorMessage += "<p>The following field(s) are missing:" + fieldsMissing;

    }

    
    if($("#password").val() == 'Abcd@1234'){

            $(".settingTabsPass").css({'display':'block'});
            $(".SetttingTabPassword").css({'display':'none'});
            $("#errorMessage").css({'display':'none'});
        }
       
    else{

            errorMessage += "<p>Please Enter a Valid Password</p>";
            $("#errorMessage").css({'display':'block'});
        }

 
   if (errorMessage != "") {

        $("#errorMessage").html(errorMessage);

    } 

    else {

        $("#errorMessage").hide();

    }
    

});

