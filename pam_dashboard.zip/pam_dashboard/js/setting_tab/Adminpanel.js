$(document).ready(function(){
    
    $('#adminlogin').click(function(){
        
        var pass = $('#Password').val();
        
        var correctpass = "Admin";
        
        if(pass == correctpass){
            
            $("#tableheader").css("display","block");
            
            $(".AdminLogin").css("display","none");
        }
        
        else{
            
            alert("wrong password");
        }
        
        
    })
    
})