function checkTime(e){return e<10&&(e="0"+e),e}function startTime(){var e=new Date,n=e.getHours(),a=e.getMinutes(),i=e.getSeconds();a=checkTime(a),i=checkTime(i),document.getElementById("time").innerHTML=n+":"+a+":"+i,t=setTimeout(function(){startTime()},500)}Date.prototype.today=function(){return(this.getDate()<10?"0":"")+this.getDate()+"-"+(this.getMonth()+1<10?"0":"")+(this.getMonth()+1)+"-"+this.getFullYear()},startTime();var datetime=(new Date).today()+" - ";function openTab(e,t){var n,a,i;for(a=document.getElementsByClassName("tabcontent"),n=0;n<a.length;n++)a[n].style.display="none";for(i=document.getElementsByClassName("tablinks"),n=0;n<i.length;n++)i[n].className=i[n].className.replace(" active","");document.getElementById(t).style.display="block",e.currentTarget.className+=" active"}document.getElementById("date").innerHTML=datetime,document.getElementById("version").innerHTML=" 3.0.0.";



$('.menu-btn').click(function(e) {

    $('.hamburgermenu').css("display", "grid");

    $('.menu-btn').css("display", "none");

    $('.cancel-btn').css("display", "block");
})

$('.cancel-btn').click(function(e) {

    $('.hamburgermenu').css("display", "none");

    $('.menu-btn').css("display", "block");

    $('.cancel-btn').css("display", "none");
        
})